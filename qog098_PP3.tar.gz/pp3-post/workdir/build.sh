#!/bin/sh
cd ..
make
