#!/bin/sh
cd ..
./a.out $1 $3
