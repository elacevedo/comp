#!/bin/sh
cd ..
lex comp.l
gcc lex.yy.c

